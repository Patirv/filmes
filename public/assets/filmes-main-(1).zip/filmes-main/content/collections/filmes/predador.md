---
id: dab4e80a-1482-4b72-9686-f92ec4698e6e
blueprint: filme
title: Predador
author: 04076d06-a4df-4abe-b243-ec8f748ced64
template: filmes/show
poster: o-predador-classificacao-indicativa-maiores-18-anos.jpg
lancamento: '1987-01-15'
categorias:
  - acao
updated_by: 04076d06-a4df-4abe-b243-ec8f748ced64
updated_at: 1666397861
---
Em uma floresta do Vietnã, um alienígena chega procurando um desafio a sua altura.