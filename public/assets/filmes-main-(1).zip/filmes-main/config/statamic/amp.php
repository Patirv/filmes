<?php

return [

    'enabled' => false,
    'route' => 'amp',

];
